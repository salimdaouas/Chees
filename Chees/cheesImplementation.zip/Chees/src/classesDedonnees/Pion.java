package classesDedonnees;

/**
 * @author bouzidia
 * @version 27-01_2021
 * Pion is an interface ,it represent a "pion"
 * pion can be of any category "cheval","soldat" and other categories
 * this interface has two methods : Pion and "deplacer"
 */

public interface Pion{
    	
	/**
	 * @author bouzidia
	 * deplacer  is a method,we use it to move "pion"
	 */
	public abstract void deplacer();
	
	
}
