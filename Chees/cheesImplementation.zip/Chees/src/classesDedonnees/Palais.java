package classesDedonnees;

import java.util.ArrayList;

/**
 * Cette classe repr�sente un palais
 * @author salim
 */
public class Palais {
	
	/**
	 * cases: c'est un tableau qui repr�sente toutes les cases 
	 * @author salim
	 */
	private ArrayList<Case> cases;
	
	/**
	 * Ceci est un constructeur d'objet de type palais
	 * @author salim
	 */
	public Palais() {}
	
}
