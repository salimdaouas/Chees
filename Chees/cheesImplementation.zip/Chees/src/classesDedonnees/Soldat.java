package classesDedonnees;

/**
 * @author bouzidia
 *@version 28_01_2021
 */
public class Soldat implements Pion {

	/**
	 * Soldat is a contructor
	 */
	public Soldat() {
		// TODO Auto-generated constructor stub
	}

	/**
	 *deplace is a method to move the Soldat
	 */
	@Override
	public void deplacer() {
		// TODO Auto-generated method stub

	}

}
