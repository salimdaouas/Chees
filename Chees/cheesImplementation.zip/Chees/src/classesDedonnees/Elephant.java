package classesDedonnees;

/**
 * @author bouzidia
 * @version 28 janvier 2021
 * This class repesents an "Elephant"
 */
public class Elephant implements Pion {

	/**
	 * Elelphant is a constructor
	 */
	public Elephant() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * deplacer is method to move the Elephant(Ministre)
	 * the implementation will depends in the moves limits of the Elephant
	 */
	@Override
	public void deplacer() {
		// TODO Auto-generated method stub

	}

}
