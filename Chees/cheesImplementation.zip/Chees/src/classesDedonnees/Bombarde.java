package classesDedonnees;

/**
 * @author bouzidia
 * @version 28 janvier 2021
 */
public class Bombarde implements Pion {

	/**
	 * Bombarde is a constructor
	 * 
	 */
	public Bombarde() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * This method is used to move the Bombarde
	 */
	@Override
	public void deplacer() {
		// TODO Auto-generated method stub

	}

}
