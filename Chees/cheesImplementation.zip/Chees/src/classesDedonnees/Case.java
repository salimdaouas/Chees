package classesDedonnees;

/**
 * Cette classe permet la cr�ation de l'objet de type case
 * @author salim
 *
 */
public class Case {
	
	
	
	
	/**
	 * Case est un constructeur de l'objet de type case
	 * @author salim
	 */
	public Case() {}
	

}
