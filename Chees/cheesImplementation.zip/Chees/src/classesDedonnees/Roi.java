package classesDedonnees;

/**
 * @author bouzidia
 * @version 28 janvier 2021
 */
public class Roi implements Pion {

	/**
	 * Roi is a constructor
	 */
	public Roi() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * deplacer is a method used to move the Roi
	 * it depends in the move's limites of the Roi
	 */
	@Override
	public void deplacer() {
		// TODO Auto-generated method stub

	}

}
