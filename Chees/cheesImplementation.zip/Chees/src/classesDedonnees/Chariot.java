package classesDedonnees;

/**
 * @author bouzidia
 * @version 28 janvier 2021
 */
public class Chariot implements Pion {

	/**
	 * This is a Constructor
	 * 
	 */
	public Chariot() {
		// TODO Auto-generated constructor stub
	}

	/**
	 *
	 */
	@Override
	public void deplacer() {
		// TODO Auto-generated method stub

	}

}
