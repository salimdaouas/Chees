package classesDedonnees;

/**
 * @author bouzidia
 * @version 28-01-2021
 * this class represents a Garde it implements the Pion interface
 */
public class Garde implements Pion {

	/**
	 * Garde is a constructor used to create a new instance of the this class
	 */
	public Garde() {
		// TODO Auto-generated constructor stub
	}

	/**
	 *deplacer is a method used to move the Garde
	 *it's defined ""en fonction des limites des deplacements de Garde" 
	 */
	@Override
	public void deplacer() {
		// TODO Auto-generated method stub

	}

}
