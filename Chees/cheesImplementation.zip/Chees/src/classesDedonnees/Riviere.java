package classesDedonnees;

/**
 * Cette classe permet la cr�ation d'objet de type riviere
 * @author salim
 */
public class Riviere {
	
	
	/**
	 * Riviere est un constructeur qui nous permet de creer un objet de type riviere
	 * @author salim
	 */
	public Riviere() {}
	

}
