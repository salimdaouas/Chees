package classesDedonnees;

/**
 * @author bouzidia
 * This class make a new "Cheval"
 * 
 */

public class Cheval implements Pion {

	/**
	 * Cheval is a constructor
	 */
	public Cheval() {
		// TODO Auto-generated constructor stub
	}

	/**
	 *deplacer is a methode used to move the "Cheval"
	 */
	@Override
	public void deplacer() {
		// TODO Auto-generated method stub

	}

}
